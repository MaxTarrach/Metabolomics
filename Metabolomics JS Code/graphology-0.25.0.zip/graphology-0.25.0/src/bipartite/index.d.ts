export {default as isBipartiteBy} from './is-bipartite-by';
