module.exports = require('graphology-simple-path');
