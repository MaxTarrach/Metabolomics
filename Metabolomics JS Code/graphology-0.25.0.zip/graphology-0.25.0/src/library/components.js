module.exports = require('graphology-components');
