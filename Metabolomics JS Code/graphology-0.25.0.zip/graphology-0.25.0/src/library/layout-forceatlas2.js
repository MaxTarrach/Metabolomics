module.exports = require('graphology-layout-forceatlas2');
