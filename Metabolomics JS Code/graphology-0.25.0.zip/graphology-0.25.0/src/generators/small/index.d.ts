export {default as krackhardtKite} from './krackhardt-kite';
