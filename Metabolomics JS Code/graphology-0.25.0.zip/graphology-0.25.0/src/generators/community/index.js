/**
 * Graphology Community Graph Generators
 * ======================================
 *
 * Community graph generators endpoint.
 */
exports.caveman = require('./caveman.js');
exports.connectedCaveman = require('./connected-caveman.js');
