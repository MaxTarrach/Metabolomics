# Changelog

## 2.2.0

- Adding `haveSameEdges` and `haveSameEdgesDeep`.

## 2.1.1

- Fixing `areSameGraphs` and `areSameGraphsDeep` wrt undirected edges.

## 2.1.0

- Making `areSameGraphs` and `areSameGraphsDeep` work with multi graphs.
