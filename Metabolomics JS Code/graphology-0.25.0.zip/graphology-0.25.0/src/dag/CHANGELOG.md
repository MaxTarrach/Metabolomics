# Changelog

## 0.2.0

- Adding `topologicalSort`.
- Adding `forEachNodeInTopologicalOrder`.

## 0.1.0

- Adding `hasCycle`.

## 0.0.1

- Adding `willCreateCycle`.
