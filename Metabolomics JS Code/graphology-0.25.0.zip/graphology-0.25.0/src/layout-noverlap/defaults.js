/**
 * Graphology Noverlap Layout Default Settings
 * ============================================
 */
module.exports = {
  gridSize: 20,
  margin: 5,
  expansion: 1.1,
  ratio: 1.0,
  speed: 3
};
