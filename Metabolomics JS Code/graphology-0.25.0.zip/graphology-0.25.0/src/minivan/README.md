# Graphology Minivan

Miscellaneous utility functions related to the [Minivan](https://github.com/medialab/minivan) bundles and to be used with [`graphology`](https://graphology.github.io).

## Installation

```
npm install graphology-minivan
```

## Usage

WIP...
