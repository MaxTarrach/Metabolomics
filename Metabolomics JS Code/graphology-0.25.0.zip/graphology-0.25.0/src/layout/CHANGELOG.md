# Changelog

## 0.6.0

- Moving `createGraphToViewportConversionFunction` to `conversion` submodule.
- Adding `collectLayout`, `collectLayoutAsFlatArray`, `assignLayout` & `assignLayoutAsFlatArray`.

## 0.5.0

- Adding `rotation`.
- Adding undocumented `createGraphToViewportConversionFunction`.
- Random layout now accepts variable dimensions.
- Circular layout now accepts custom dimensions.
