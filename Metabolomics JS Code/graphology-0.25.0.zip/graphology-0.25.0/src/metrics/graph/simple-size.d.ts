import Graph from 'graphology-types';

export default function simpleSize(graph: Graph): number;
