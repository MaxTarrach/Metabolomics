import Graph from 'graphology-types';

export default function neighborhoodPreservation(graph: Graph): number;
