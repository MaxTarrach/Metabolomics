import Graph from 'graphology-types';

export default function stress(graph: Graph): number;
