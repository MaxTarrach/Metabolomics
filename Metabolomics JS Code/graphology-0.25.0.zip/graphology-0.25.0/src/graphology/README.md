# Graphology

`graphology` is a specification for a robust & multipurpose JavaScript `Graph` object and aiming at supporting various kinds of graphs under a same unified interface.

You will also find here the source for the reference implementation of this specification.

## Documentation

Full documentation for the library/specs is available [here](https://graphology.github.io).
