/**
 * Graphology CommonJS Endoint
 * ============================
 *
 * Endpoint for CommonJS modules consumers.
 */
import {Graph} from './classes';

export default Graph;
