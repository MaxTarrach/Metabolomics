export type GraphmlParserOptions = {
  addMissingNodes?: boolean;
};
