import Graph from 'graphology-types';

export default function reverse<G extends Graph>(graph: G): G;
