# Changelog

## 0.2.2

- Tighter `graphology-utils` dependency.

## 0.2.1

- Fixing worker

## 0.2.0

- Revamping parameters.
