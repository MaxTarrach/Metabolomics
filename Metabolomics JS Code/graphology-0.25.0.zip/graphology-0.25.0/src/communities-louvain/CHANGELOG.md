# Changelog

# 2.0.1

- Updating dependency on `graphology-indices`.

# 2.0.0

- Adapting to new getters paradigm across standard library.
