# Changelog

## 0.4.0

- Adding `#.isRunning` to worker.
