/**
 * Graphology Browser GEXF Writer
 * ===============================
 *
 * This is just an alias to common/writer.
 */
module.exports = require('../common/writer.js');
