/**
 * Graphology GEXF
 * ================
 *
 * Library endpoint.
 */
module.exports = require('./node/index.js');
