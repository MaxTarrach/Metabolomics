/**
 * Graphology Small Graph Generators
 * ==================================
 *
 * Small graph generators endpoint.
 */
exports.krackhardtKite = require('./krackhardt-kite.js');
