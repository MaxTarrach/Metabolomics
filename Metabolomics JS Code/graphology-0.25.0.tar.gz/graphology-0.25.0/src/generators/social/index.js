/**
 * Graphology Social Graph Generators
 * ===================================
 *
 * Social graph generators endpoint.
 */
exports.florentineFamilies = require('./florentine-families.js');
exports.karateClub = require('./karate-club.js');
