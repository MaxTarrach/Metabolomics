import Graph from 'graphology-types';

export default function willCreateCycle(
  graph: Graph,
  source: unknown,
  target: unknown
): boolean;
