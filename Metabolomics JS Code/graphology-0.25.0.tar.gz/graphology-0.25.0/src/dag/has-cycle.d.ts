import Graph from 'graphology-types';

export default function hasCycle(graph: Graph): boolean;
