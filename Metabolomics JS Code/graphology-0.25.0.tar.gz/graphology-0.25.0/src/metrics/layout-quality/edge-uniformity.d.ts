import Graph from 'graphology-types';

export default function edgeUniformity(graph: Graph): number;
