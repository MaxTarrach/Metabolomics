exports.edgeUniformity = require('./edge-uniformity.js');
exports.neighborhoodPreservation = require('./neighborhood-preservation.js');
exports.stress = require('./stress.js');
