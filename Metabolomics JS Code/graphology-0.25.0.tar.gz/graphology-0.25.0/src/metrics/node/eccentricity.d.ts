import Graph from 'graphology-types';

export default function eccentricity(graph: Graph, node: unknown): number;
