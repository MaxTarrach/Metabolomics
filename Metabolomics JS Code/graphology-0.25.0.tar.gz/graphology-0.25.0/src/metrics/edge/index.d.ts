export {default as disparity} from './disparity';
export {default as simmelianStrength} from './simmelian-strength';
