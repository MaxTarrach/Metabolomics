exports.disparity = require('./disparity.js');
exports.simmelianStrength = require('./simmelian-strength.js');
