import Graph from 'graphology-types';

export default function diameter(graph: Graph): number;
