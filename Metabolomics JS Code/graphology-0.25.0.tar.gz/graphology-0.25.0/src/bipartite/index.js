exports.isBipartiteBy = require('./is-bipartite-by.js');
