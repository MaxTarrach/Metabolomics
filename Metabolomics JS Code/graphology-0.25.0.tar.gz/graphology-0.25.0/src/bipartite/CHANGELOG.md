# Changelog

## 0.0.3

- Adding index and type declarations.

## 0.0.2

- Adding missing files to package.

## 0.0.1

- Initial release.
