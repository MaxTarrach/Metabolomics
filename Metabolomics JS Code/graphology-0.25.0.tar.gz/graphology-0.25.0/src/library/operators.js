module.exports = require('graphology-operators');
