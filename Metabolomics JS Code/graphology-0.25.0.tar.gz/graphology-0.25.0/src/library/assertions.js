module.exports = require('graphology-assertions');
