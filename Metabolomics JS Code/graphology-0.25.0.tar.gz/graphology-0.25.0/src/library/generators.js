module.exports = require('graphology-generators');
