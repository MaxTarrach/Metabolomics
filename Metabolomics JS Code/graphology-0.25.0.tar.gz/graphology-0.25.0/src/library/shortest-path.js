module.exports = require('graphology-shortest-path');
