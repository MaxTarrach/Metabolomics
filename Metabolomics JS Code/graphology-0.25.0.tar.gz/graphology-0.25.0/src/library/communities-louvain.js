module.exports = require('graphology-communities-louvain');
