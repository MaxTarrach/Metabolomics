/**
 * Graphology GRAPHML
 * ===================
 *
 * Library endpoint.
 */
module.exports = require('./node/index.js');
