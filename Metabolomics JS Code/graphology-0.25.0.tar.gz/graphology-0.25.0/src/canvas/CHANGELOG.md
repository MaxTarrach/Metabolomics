# Changelog

## 0.4.0

- Renaming `margin` to `padding`.
- Adapting coordinate conversion to latest sigma developments.
