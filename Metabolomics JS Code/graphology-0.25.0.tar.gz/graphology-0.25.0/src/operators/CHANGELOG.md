# Changelog

## 1.6.0

- Adding options to `toSimple`.
- Improved performance of `toSimple`.

## 1.5.0

- Adding `toMulti`.
- Adding `toMixed`.

## 1.4.3

- Fixing `toDirected` and `toUndirected` wrt multi graphs.

## 1.4.2

- Fixing `toDirected` wrt self-loops.
- Improving most type declarations wrt generics.
- Dropping obsolete reference to generated keys.
